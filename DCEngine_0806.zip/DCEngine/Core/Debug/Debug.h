/******************************************************************************/
/*!
\file   Debug.h
\author Christian Sagel
\par    email: c.sagel\@digipen.edu
\date   7/30/2015
\brief

*/
/******************************************************************************/

#include <string>
#include <iostream>

#pragma once

namespace Debug {

  void PrintString(std::string sentence);
  void PrintFPS(float dt);
}
