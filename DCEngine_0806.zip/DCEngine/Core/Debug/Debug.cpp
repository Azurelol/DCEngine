/******************************************************************************/
/*!
\file   Debug.cpp
\author Christian Sagel
\par    email: c.sagel\@digipen.edu
\date   7/30/2015
\brief

*/
/******************************************************************************/
#include "Debug.h"

namespace Debug {

  /**************************************************************************/
  /*!
  \brief  Given a string, prints it to the console.
  \param  sentence  
  */
  /**************************************************************************/
  void PrintString(std::string sentence) {
    std::cout << sentence << std::endl;
  }

  /**************************************************************************/
  /*!
  \brief  Prints the current FPS to the console.
  \note   This function call can be made much easier using the GETSYSTEM
  macro that takes a system typename and expands it to fill the
  template parameters.
  */
  /**************************************************************************/
  void PrintFPS(float dt) {
    std::cout << "FPS: " << dt << std::endl;
  }

} // Debug
