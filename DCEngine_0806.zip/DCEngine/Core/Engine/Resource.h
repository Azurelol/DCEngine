/*****************************************************************************/
/*!
\file   Resource.h
\author Christian Sagel
\par    email: c.sagel\@digipen.edu
\date   8/5/2015
\brief  A resource 

*/
/******************************************************************************/
#pragma once

#include "Object.h"

namespace DCEngine {

  class Resource : public Object {

  };

}