/******************************************************************************/
/*!
* \author Joshua T. Fisher
* \date   6/7/2015
*
* \copyright All content 2015 DigiPen (USA) Corporation, all rights reserved.
*/
/******************************************************************************/
#pragma once

#ifndef YTE_Core_Object_h
#define YTE_Core_Object_h

#include "Utilities/JsonHelpers.h"

#include "Zilchbind/ForwardDeclarations.h"

#include "ScriptBind.h"

namespace YTE
{
  namespace Core
  {
    class Object : public Zilch::IZilchObject
    {
    public:
      template <typename MetaBoundType>
      inline void Serialize(Zilch::JsonValue *aProperties, ZilchBind::ZilchBinder *aZilchBinder, MetaBoundType aSelf, Zilch::BoundType *aType)
      {
        // Nothing to serialize
        if (aProperties == nullptr)
        {
          return;
        }

        ZilchForEach(auto property, aProperties->OrderedMembers.all())
        {
          Zilch::JsonValue *value = property->Value;

          Zilch::Property *namedProperty = aType->GetInstanceProperty(property->Key);

          if (namedProperty == nullptr)
          {
            namedProperty = aType->GetInstanceField(property->Key);
          }

          if (namedProperty != nullptr)
          {
            // If the bound field/property does not have the Property Attribute, do nothing.
            if (!namedProperty->HasAttribute("Property"))
            {
              continue;
            }

            Zilch::ExceptionReport report;
            Zilch::Call call(namedProperty->Set, aZilchBinder->mState);

            call.SetHandle(Zilch::Call::This, aSelf);

            bool isValidProperty = true;

            // Type is a float
            if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::Real)))
            {
              call.Set(0, value->AsFloat());
              //float test = call.Get<float>(0);
            }
            // Type is an int.
            else if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::Integer)))
            {
              call.Set(0, value->AsInteger());
            }
            // Type is a string.
            else if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::String)))
            {
              call.Set(0, value->AsString());
            }
            // Type is a Boolean.
            else if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::Boolean)))
            {
              call.Set(0, value->AsBool());
            }
            // Type is a Real2.
            else if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::Real2)))
            {
              call.Set(0, ValueAsReal2(value));
            }
            // Type is a Real3.
            else if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::Real3)))
            {
              call.Set(0, ValueAsReal3(value));
            }
            // Type is a Real4.
            else if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::Real4)))
            {
              call.Set(0, ValueAsReal4(value));
            }
            // Type is a Quaternion.
            else if (Zilch::Type::IsSame(namedProperty->PropertyType, ZilchTypeId(Zilch::Quaternion)))
            {
              call.Set(0, ValueAsQuaternion(value));
            }
            // Type is invalid.
            else
            {
              isValidProperty = false;
              std::cout << "Attempting to read property " << property->Key.c_str()
                << " from " << aType->Name.c_str() << " as a "
                << namedProperty->PropertyType->ToString().c_str()
                << " which is not supported" << std::endl;
            }

            if (isValidProperty)
              call.Invoke(report);
          }
          else
          {
            std::cout << "You have likely removed " << property->Key.c_str()
              << " from " << aType->Name.c_str()
              << " but are still serializing it." << std::endl;
          }
        }
      };

      inline String Deserialize() 
      {
        Zilch::JsonBuilder builder;
        builder.Begin(Zilch::JsonType::Object);
        {
          Deserialize(builder);
        }
        builder.End();

        Zilch::String jsonRepresentation = builder.ToString();

        return MakeString(jsonRepresentation);
      };

       // If you've asserted here, this isn't implemented, but Deserialize has been called.
      virtual void Deserialize(Zilch::JsonBuilder &aBuilder) { assert(false); };

    protected:
      template <typename MetaBoundType>
      void DeserializeByType(Zilch::JsonBuilder &aBuilder, Zilch::ExecutableState *aState, MetaBoundType aSelf, Zilch::BoundType *aType)
      {
        Zilch::PropertyArray &properties = aType->AllProperties;
        Zilch::ExceptionReport report;

        for (uint i = 0; i < properties.size(); ++i)
        {
          Zilch::Property *property = properties[i];

          // If the bound field/property does not have the Property Attribute, do nothing.
          if (!property->HasAttribute("Property"))
          {
            continue;
          }

          aBuilder.Key(property->Name);

            // Set up the get so we can serialize it's value.
          Zilch::Call getCall(property->Get, aState);
          getCall.SetHandle(Zilch::Call::This, aSelf);
          getCall.Invoke(report);

          // Type is a float
          if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::Real)))
          {
            aBuilder.Value(getCall.Get<Zilch::Real>(Zilch::Call::Return));
          }
          // Type is an int.
          else if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::Integer)))
          {
            aBuilder.Value(getCall.Get<Zilch::Integer>(Zilch::Call::Return));
          }
          // Type is a string.
          else if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::String)))
          {
            aBuilder.Value(getCall.Get<Zilch::String>(Zilch::Call::Return));
          }
          // Type is a Boolean.
          else if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::Boolean)))
          {
            aBuilder.Value(getCall.Get<Zilch::Boolean>(Zilch::Call::Return));
          }
          // Type is a Real2.
          else if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::Real2)))
          {
            auto value = getCall.Get<Zilch::Real2>(Zilch::Call::Return);
            Real2AsValue(aBuilder, value);
          }
          // Type is a Real3.
          else if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::Real3)))
          {
            auto value = getCall.Get<Zilch::Real3>(Zilch::Call::Return);
            Real3AsValue(aBuilder, value);
          }
          // Type is a Real4.
          else if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::Real4)))
          {
            auto value = getCall.Get<Zilch::Real4>(Zilch::Call::Return);
            Real4AsValue(aBuilder, value);
          }
          // Type is a Quaternion.
          else if (Zilch::Type::IsSame(property->PropertyType, ZilchTypeId(Zilch::Quaternion)))
          {
            auto value = getCall.Get<Zilch::Quaternion>(Zilch::Call::Return);
            QuaternionAsValue(aBuilder, value);
          }
        }
      }

    private:
      ZilchDeclareBaseType(Object, Zilch::TypeCopyMode::ReferenceType);
    };
  }
}

#endif