﻿//All content © 2014 DigiPen (USA) Corporation, all rights reserved.
/*******************************************************************************/
/*!
\file   FactoryInitilization.h
\author Joshua T. Fisher
\par    email: j.fisher\@digipen.edu
\par    DigiPen login: j.fisher
\par    Course: GAM 200
\date   10/24/2014
\brief
  Sets up the component factories.
*/
/******************************************************************************/
#pragma once

#ifndef YTE_CORE_FACTORY_INITIALIZATION_H
#define YTE_CORE_FACTORY_INITIALIZATION_H

#include <unordered_map>
#include <memory>

#include "Component/Component.h"
#include "Component/ComponentFactory.h"

#include "Graphics/YTEModel.h"

#include "Utilities/String/String.h"

#define DeclareComponent(component)                                                                     \
  it = currComponentFactories.find(##component::ZilchGetStaticType());                                  \
                                                                                                        \
  if (it == currComponentFactories.end())                                                               \
  {                                                                                                     \
    currComponentFactories.emplace(##component::ZilchGetStaticType(),                                   \
	                                 std::make_unique<YTE::Component::ComponentFactory<##component> >()); \
  }                               

void CoreComponentFactoryInitilization(std::unordered_map<Zilch::BoundType*, 
                                                          std::unique_ptr<YTE::Component::StringComponentFactory> > &currComponentFactories)
{
  auto it = currComponentFactories.begin();
  
  DeclareComponent(YTE::Graphics::Model)
  DeclareComponent(YTE::Component::TestComponent)
}

#undef DeclareComponent

#endif