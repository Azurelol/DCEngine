/******************************************************************************/
/*!
* \author Joshua T. Fisher
* \date   6/7/2015
*
* \copyright All content 2015 DigiPen (USA) Corporation, all rights reserved.
*/
/******************************************************************************/
#pragma once

#ifndef YTE_Utilities_JsonHelpers_h
#define YTE_Utilities_JsonHelpers_h

#include "Zilch/Zilch.hpp"

namespace YTE
{
  ///////////////////////////////
  // Real2
  ///////////////////////////////
  inline Zilch::Real2 ValueAsReal2(Zilch::JsonValue *aValue)
  {
    auto real4 = aValue->GetMember("Vector2");
    auto x = real4->GetMember("x")->AsFloat();
    auto y = real4->GetMember("y")->AsFloat();
    return Zilch::Real2(x, y);
  }

  inline void Real2AsValue(Zilch::JsonBuilder &aBuilder, Zilch::Real2 aValue)
  {
    aBuilder.Key("Vector2");
    aBuilder.Begin(Zilch::JsonType::Object);
    {
      aBuilder.Key("x");
      aBuilder.Value(aValue.x);
      aBuilder.Key("y");
      aBuilder.Value(aValue.y);
    }
    aBuilder.End();
  }

  ///////////////////////////////
  // Real3
  ///////////////////////////////
  inline Zilch::Real3 ValueAsReal3(Zilch::JsonValue *aValue)
  {
    auto real4 = aValue->GetMember("Vector3");
    auto x = real4->GetMember("x")->AsFloat();
    auto y = real4->GetMember("y")->AsFloat();
    auto z = real4->GetMember("z")->AsFloat();
    return Zilch::Real3(x, y, z);
  }

  inline void Real3AsValue(Zilch::JsonBuilder &aBuilder, Zilch::Real3 aValue)
  {
    aBuilder.Key("Vector3");
    aBuilder.Begin(Zilch::JsonType::Object);
    {
      aBuilder.Key("x");
      aBuilder.Value(aValue.x);
      aBuilder.Key("y");
      aBuilder.Value(aValue.y);
      aBuilder.Key("z");
      aBuilder.Value(aValue.z);
    }
    aBuilder.End();
  }

  ///////////////////////////////
  // Real4
  ///////////////////////////////
  inline Zilch::Real4 ValueAsReal4(Zilch::JsonValue *aValue)
  {
    auto real4 = aValue->GetMember("Vector4");
    auto x = real4->GetMember("x")->AsFloat();
    auto y = real4->GetMember("y")->AsFloat();
    auto z = real4->GetMember("z")->AsFloat();
    auto w = real4->GetMember("w")->AsFloat();
    return Zilch::Real4(x, y, z, w);
  }

  inline void Real4AsValue(Zilch::JsonBuilder &aBuilder, Zilch::Real4 aValue)
  {
    aBuilder.Key("Vector4");
    aBuilder.Begin(Zilch::JsonType::Object);
    {
      aBuilder.Key("x");
      aBuilder.Value(aValue.x);
      aBuilder.Key("y");
      aBuilder.Value(aValue.y);
      aBuilder.Key("z");
      aBuilder.Value(aValue.z);
      aBuilder.Key("w");
      aBuilder.Value(aValue.w);
    }
    aBuilder.End();
  }

  ///////////////////////////////
  // Quaternion
  ///////////////////////////////
  inline Zilch::Quaternion ValueAsQuaternion(Zilch::JsonValue *aValue)
  {
    auto quaternion = aValue->GetMember("Quaternion");
    auto x = quaternion->GetMember("x")->AsFloat();
    auto y = quaternion->GetMember("y")->AsFloat();
    auto z = quaternion->GetMember("z")->AsFloat();
    auto w = quaternion->GetMember("w")->AsFloat();
    return Zilch::Quaternion(x,y,z,w);
  }

  inline void QuaternionAsValue(Zilch::JsonBuilder &aBuilder, Zilch::Quaternion aValue)
  {
    aBuilder.Key("Quaternion");
    aBuilder.Begin(Zilch::JsonType::Object);
    {
      aBuilder.Key("x");
      aBuilder.Value(aValue.x);
      aBuilder.Key("y");
      aBuilder.Value(aValue.y);
      aBuilder.Key("z");
      aBuilder.Value(aValue.z);
      aBuilder.Key("w");
      aBuilder.Value(aValue.w);
    }
    aBuilder.End();
  }
}

#endif