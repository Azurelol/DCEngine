
Component* Composition::AddComponent(Zilch::BoundType *aType, Zilch::JsonValue* aProperties)
{
  auto addFactory = mSpace->GetComponentSystem()->GetComponentFactories()->at(aType).get();

  auto component = addFactory->AddComponent(this, mSpace, aProperties);
  
  mComponents.emplace(aType, component);

  return component;
}


  
template <typename T>
T *ComponentFactory<T>::AddComponent(Composition *aOwner,
                                     Core::Space *aSpace,
                                     Zilch::JsonValue *aArguments)
{
  // Don't add more than one component with the same id
  if (mComponents.count(aOwner) == 1)
  {
    __debugbreak();
  }

  // Just use new.
  mComponents.emplace(std::piecewise_construct,
                      std::forward_as_tuple(aOwner),
                      std::forward_as_tuple(aOwner, aSpace, this, aArguments));

  return &mComponents.at(aOwner);
}