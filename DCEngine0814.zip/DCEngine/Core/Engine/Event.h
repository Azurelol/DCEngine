#pragma once
#include <string>

namespace DCEngine {

  class Event {
  public:

  private:
    std::string _eventId;


  };

}