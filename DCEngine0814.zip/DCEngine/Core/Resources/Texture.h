/******************************************************************************/
/*!
\file   Texture.h
\author Christian Sagel
\par    email: c.sagel\@digipen.edu
\date   8/1/2015
\brief  My study of the "Textures" tutorial:
"http://learnopengl.com/#!Getting-started/Textures"

*/
/******************************************************************************/
#pragma once
#include "..\Engine\Resource.h"

namespace DCEngine {

  class Texture : public Resource {


  };


}