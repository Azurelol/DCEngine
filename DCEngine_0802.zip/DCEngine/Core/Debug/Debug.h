#include <string>
#include <iostream>

#pragma once
//#ifndef DEBUG_H
//#define DEBUG_H

namespace Debug {

  void PrintString(std::string sentence);
  void PrintFPS(float dt);
}

//#endif