#include "Debug.h"


namespace Debug {

  void PrintString(std::string sentence) {
    std::cout << sentence << std::endl;
  }

  void PrintFPS(float dt) {
    std::cout << "FPS: " << dt << std::endl;
  }

}
