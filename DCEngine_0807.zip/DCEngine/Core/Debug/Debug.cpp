/******************************************************************************/
/*!
\file   Debug.cpp
\author Christian Sagel
\par    email: c.sagel\@digipen.edu
\date   7/30/2015
\brief

*/
/******************************************************************************/
#include "Debug.h"
#include <memory>

namespace Debug {  

  std::unique_ptr<Trace> trace = nullptr;


  /**************************************************************************/
  /*!
  \brief  Creates the trace object.
  \param  sentence  
  */
  /**************************************************************************/
  Trace::Trace(std::string fileName) {
    _file.open(fileName);
    std::cout << "Debug::Trace - Log file: " << fileName << std::endl;
  }

  /**************************************************************************/
  /*!
  \brief  Destructor. Closes the file.
  \param  sentence
  */
  /**************************************************************************/
  Trace::~Trace() {
    _file.close();
    std::cout << "Debug::~Trace - Closing" << std::endl;
  }


} // Debug
