#pragma once

/*
    WINDOW HANDLING
                      */
#include "../Systems/Window/WindowGLFW.h"

/*
    GRAPHICS
                */
#include "../Systems/Graphics/GraphicsGL.h"