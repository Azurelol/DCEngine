#pragma once

/*
    WINDOW HANDLING, INPUT
                            */
#include "../Systems/Window/Window.h"
#include "../Systems/Input/Input.h"

/*
    GRAPHICS
                */
#include "../Systems/Graphics/GraphicsGL.h"