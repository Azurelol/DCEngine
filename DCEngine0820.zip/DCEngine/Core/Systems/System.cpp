/******************************************************************************/
/*!
\file   System.cpp
\author Christian Sagel
\par    email: c.sagel\@digipen.edu
\date   7/30/2015
\brief  The base System class.

*/
/******************************************************************************/
#include "System.h"


void DCEngine::System::ClearEntities() {
  _entities.clear();
}
