#pragma once

#include <string>

namespace DCEngine {
  namespace Config {

    static std::string DefaultSpace = "Daisy World";
    static std::string shaderLocation = "Tutorials/";


  }

}

